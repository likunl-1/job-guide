# 项目结构说明

## 📂 完整目录结构

```
workspace/projects/
│
├── 📄 README.md                      # 项目主页
├── 📄 requirements.txt               # Python依赖
├── 📄 .gitignore                     # Git忽略配置
├── 📄 .env.example                   # 环境变量示例
├── 📄 Dockerfile                     # Docker构建文件
├── 📄 docker-compose.yml             # Docker Compose配置
├── 📄 功能清单_完整说明.md           # 功能详细说明
│
├── 📁 src/                          # 源代码（核心）
│   ├── main.py                       # 程序入口
│   ├── agents/                       # Agent逻辑
│   │   ├── agent.py                  # 主Agent
│   │   └── __init__.py
│   ├── tools/                        # 工具集
│   │   ├── web_search_tool.py        # 联网搜索
│   │   ├── resume_reader_tool.py     # 简历读取
│   │   ├── visualization_tool.py     # 数据可视化
│   │   ├── wordcloud_tool.py         # 词云生成
│   │   ├── html_report_tool.py       # HTML报告
│   │   ├── multi_mode_search.py      # 多模式搜索
│   │   ├── user_profile_tool.py      # 用户画像
│   │   ├── read_jobs_data.py         # 数据读取
│   │   └── recruitment_api_client.py # API客户端
│   ├── utils/                        # 工具函数
│   │   ├── helper/                   # 辅助函数
│   │   ├── file/                     # 文件操作
│   │   ├── log/                      # 日志系统
│   │   └── messages/                 # 消息处理
│   ├── storage/                      # 存储层
│   │   ├── database/                 # 数据库
│   │   └── s3/                       # 对象存储
│   └── graphs/                       # 图结构
│
├── 📁 config/                       # 配置文件
│   └── agent_llm_config.json         # Agent配置
│
├── 📁 tests/                        # 测试文件
│   ├── test_*.py                     # 单元测试
│   ├── generate_*.py                 # 生成测试数据
│   └── verify_*.py                   # 验证工具
│
├── 📁 scripts/                      # 脚本工具
│   └── load_env.py                   # 环境加载
│
├── 📁 web/                          # Web前端
│   ├── index.html                    # 主页
│   ├── app.js                        # 前端逻辑
│   └── style.css                     # 样式文件
│
├── 📁 docs/                         # 📖 文档中心
│   ├── deployment/                   # 部署文档
│   │   ├── 快速部署指南.md
│   │   ├── Agent部署完整指南.md
│   │   └── 在线演示地址.md
│   ├── usage/                        # 使用文档
│   │   ├── 使用指南.md
│   │   └── HTML报告生成使用指南.md
│   ├── development/                  # 开发文档
│   │   ├── 实现路径PPT大纲-功能实现部分.md
│   │   └── technical-fixes/          # 技术修复
│   │       ├── Markdown渲染功能修复说明.md
│   │       ├── wordcloud_chinese_fix.md
│   │       └── filename_special_chars_fix.md
│   ├── course/                       # 课程作业
│   │   └── 功能实现部分视频录制脚本.md
│   ├── api/                          # API文档
│   └── samples/                      # 示例
│       └── sample-report*.html
│
├── 📁 assets/                       # 💾 资源中心
│   ├── README.md                     # 目录说明
│   │
│   ├── 📁 charts/                    # ⚠️ AI Agent生成图表（勿删）
│   │   ├── 词云图/
│   │   ├── 趋势图/
│   │   └── 分布图/
│   │
│   ├── 📁 reports/                   # ⚠️ AI Agent生成报告（勿删）
│   │   ├── test_*.html               # 测试报告
│   │   └── comprehensive_report*.html
│   │
│   ├── 📁 jobs_data/                 # ⚠️ 招聘数据（AI Agent读取）
│   │   └── {关键词}_招聘数据.xlsx
│   │
│   ├── 📁 resumes/                   # ⚠️ 用户简历（AI Agent读取）
│   │   └── {姓名}_简历.{pdf|docx}
│   │
│   ├── 📁 documents/                 # 文档资源
│   │   ├── introductions/            # 介绍文档
│   │   │   └── 就业指导ai-agent介绍报告.html ⭐
│   │   ├── cases/                    # 案例文档
│   │   │   └── historical_economic_cases.md
│   │   └── team/                     # 团队文档
│   │       └── team-contribution.html
│   │
│   ├── 📁 examples/                  # 示例数据
│   │   ├── jobs_data/                # 示例招聘数据
│   │   └── resumes/                  # 示例简历
│   │
│   └── 📁 presentations/              # 演示材料
│       ├── images/                   # 演示图片
│       └── videos/                   # 演示视频
│           ├── intro/                # 介绍视频（预留）
│           │   └── project-introduction.{mp4|mov}
│           └── reports/              # 展示报告视频（预留）
│               ├── report-01-{功能}.{mp4|mov}
│               ├── report-02-{功能}.{mp4|mov}
│               └── report-03-{功能}.{mp4|mov}
│
└── 📁 其他配置文件
    ├── .coze                         # Coze配置
    ├── .dockerignore                 # Docker忽略
    ├── .nixpacks.toml                # Nixpacks配置
    ├── Procfile                      # Procfile配置
    └── railway.toml                  # Railway配置
```

## 🔍 目录分类说明

### 🟢 核心运行目录（AI Agent 必需）
这些目录是AI Agent运行的核心，**请勿删除或修改**：

| 目录 | 用途 | 说明 |
|------|------|------|
| `src/` | 源代码 | 所有Agent逻辑和工具实现 |
| `config/` | 配置文件 | Agent和模型配置 |
| `assets/charts/` | 图表输出 | Agent自动生成图表的位置 |
| `assets/reports/` | 报告输出 | Agent生成HTML报告的位置 |
| `assets/jobs_data/` | 数据输入 | Agent读取招聘数据的位置 |
| `assets/resumes/` | 简历输入 | Agent读取用户简历的位置 |

### 🟡 文档目录（项目说明）
这些目录包含项目文档，重组后更加结构化：

| 目录 | 用途 | 主要内容 |
|------|------|---------|
| `docs/deployment/` | 部署指南 | 快速部署、Agent部署、在线演示 |
| `docs/usage/` | 使用指南 | 使用说明、HTML报告生成 |
| `docs/development/` | 开发文档 | 实现路径、技术修复 |
| `docs/course/` | 课程作业 | 视频脚本、PPT大纲 |
| `assets/documents/` | 文档资源 | 介绍报告、历史案例、团队贡献 |

### 🔵 资源目录（扩展材料）
这些目录存放演示材料和示例数据：

| 目录 | 用途 | 说明 |
|------|------|------|
| `assets/examples/` | 示例数据 | 招聘数据示例、简历示例 |
| `assets/presentations/` | 演示材料 | 图片、视频（预留） |

## 📌 快速导航

### 我想...
- **了解项目** → [项目介绍报告](../assets/documents/introductions/就业指导ai-agent介绍报告.html)
- **快速开始** → [快速部署指南](../docs/deployment/快速部署指南.md)
- **部署到云端** → [Agent部署完整指南](../docs/deployment/Agent部署完整指南.md)
- **查看文档** → [文档中心](../docs/)
- **查看代码** → [源代码目录](../src/)
- **添加数据** → [assets/README.md](../assets/README.md)

## ⚠️ 重要提醒

### 关于 AI Agent 功能
AI Agent 运行依赖以下目录，重组时**保持不变**：
- ✅ `assets/charts/` - 图表输出目录
- ✅ `assets/reports/` - 报告输出目录
- ✅ `assets/jobs_data/` - 数据输入目录
- ✅ `assets/resumes/` - 简历输入目录

### 关于视频上传
- 介绍视频（1个）→ `assets/presentations/videos/intro/`
- 展示报告视频（3个）→ `assets/presentations/videos/reports/`

### 关于文档查找
- 所有文档已整合到 `docs/` 目录
- 按功能分类：deployment、usage、development、course
- 项目介绍等重要HTML文档在 `assets/documents/`

## 🔄 重组对比

### 重组前的问题
- ❌ 文档分散在根目录、docs/、web/
- ❌ assets/ 目录文件混杂，不易查找
- ❌ 介绍报告等重要文件位置不明显

### 重组后的改进
- ✅ 文档统一在 `docs/`，按功能分类
- ✅ assets/ 目录结构清晰，易于扩展
- ✅ 重要文档位置显眼，易于发现
- ✅ 为视频和展示报告预留位置
- ✅ 保持AI Agent功能路径不变
