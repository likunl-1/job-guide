#!/bin/bash
 
pip freeze > requirements.txt
