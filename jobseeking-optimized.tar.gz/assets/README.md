# Assets 资源目录说明

## 目录结构

### 📁 核心数据目录（AI Agent 运行必需）
```
assets/
├── charts/              # 生成的图表（系统自动生成，勿删除）
├── reports/             # 生成的HTML报告（系统自动生成，勿删除）
├── jobs_data/           # 招聘数据文件（八爪鱼采集的数据）
└── resumes/             # 用户简历文件（用户上传）
```

### 📁 文档目录
```
assets/
└── documents/
    ├── introductions/   # 项目介绍文档
    │   └── 就业指导ai-agent介绍报告.html ⭐
    ├── cases/          # 历史案例
    │   └── historical_economic_cases.md
    └── team/           # 团队相关
        └── team-contribution.html
```

### 📁 示例数据目录
```
assets/
└── examples/
    ├── jobs_data/      # 示例招聘数据
    └── resumes/        # 示例简历
```

### 📁 演示材料目录
```
assets/
└── presentations/
    ├── images/         # 演示图片
    └── videos/         # 演示视频
        ├── intro/      # 介绍视频（预留）
        └── reports/    # 展示报告视频（预留）
```

## 重要说明

### ⚠️ 以下目录是AI Agent运行必需，勿随意删除或修改
- `charts/` - Agent生成图表的输出目录
- `reports/` - Agent生成HTML报告的输出目录
- `jobs_data/` - Agent读取招聘数据的目录
- `resumes/` - Agent读取用户简历的目录

### 📖 核心文档
- **项目介绍报告**: `documents/introductions/就业指导ai-agent介绍报告.html` ⭐ 必读
- **团队贡献说明**: `documents/team/team-contribution.html`
- **历史经济案例**: `documents/cases/historical_economic_cases.md`

## 添加新文件

### 添加演示视频
1. 介绍视频 → `presentations/videos/intro/`
2. 展示报告视频 → `presentations/videos/reports/`

### 添加招聘数据
1. 八爪鱼采集的Excel文件 → `jobs_data/`
2. 命名规范: `{关键词}_招聘数据.xlsx`

### 添加简历文件
1. 用户简历PDF/Word → `resumes/`
2. 命名规范: `{姓名}_简历.{pdf|docx}`

### 添加示例数据
1. 示例招聘数据 → `examples/jobs_data/`
2. 示例简历 → `examples/resumes/`
